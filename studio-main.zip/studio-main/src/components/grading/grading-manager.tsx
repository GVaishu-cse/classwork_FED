"use client";

import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/hooks/use-auth";
import { db } from "@/lib/firebase";
import {
  collection,
  doc,
  getDocs,
  setDoc,
  addDoc,
  deleteDoc,
  query,
} from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { sampleStudents } from "@/lib/data";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Loader2,
  PlusCircle,
  Trash2,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableCaption,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import type { Student, Grade } from "@/types";

const gradeSchema = z.object({
  assignment: z.string().min(1, "Assignment name is required."),
  score: z.coerce.number().min(0, "Score cannot be negative."),
  total: z.coerce.number().min(1, "Total must be at least 1."),
});

export default function GradingManager() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [students] = useState<Student[]>(sampleStudents);
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(
    sampleStudents.length > 0 ? sampleStudents[0].id : null
  );
  const [grades, setGrades] = useState<Grade[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const form = useForm<z.infer<typeof gradeSchema>>({
    resolver: zodResolver(gradeSchema),
    defaultValues: { assignment: "", score: 0, total: 100 },
  });

  const fetchGrades = useCallback(async () => {
    if (!user || !selectedStudentId) return;
    setIsLoading(true);
    try {
      const gradesCol = collection(
        db,
        `users/${user.uid}/students/${selectedStudentId}/grades`
      );
      const q = query(gradesCol);
      const querySnapshot = await getDocs(q);
      const fetchedGrades: Grade[] = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      } as Grade));
      setGrades(fetchedGrades);
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not fetch grades.",
      });
    } finally {
      setIsLoading(false);
    }
  }, [user, selectedStudentId, toast]);

  useEffect(() => {
    if(selectedStudentId) {
      fetchGrades();
    } else {
      setGrades([]);
    }
  }, [selectedStudentId, fetchGrades]);

  const handleAddGrade = async (values: z.infer<typeof gradeSchema>) => {
    if (!user || !selectedStudentId) return;
    setIsSubmitting(true);
    try {
      const gradesCol = collection(
        db,
        `users/${user.uid}/students/${selectedStudentId}/grades`
      );
      await addDoc(gradesCol, values);
      toast({
        title: "Success",
        description: "Grade added successfully.",
      });
      fetchGrades();
      form.reset();
      setIsDialogOpen(false);
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not add grade.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteGrade = async (gradeId: string) => {
    if (!user || !selectedStudentId) return;
    
    const originalGrades = [...grades];
    setGrades(grades.filter(g => g.id !== gradeId));

    try {
        const gradeDoc = doc(db, `users/${user.uid}/students/${selectedStudentId}/grades/${gradeId}`);
        await deleteDoc(gradeDoc);
        toast({
            title: "Success",
            description: "Grade deleted.",
        });
    } catch (error) {
        console.error(error);
        toast({
            variant: "destructive",
            title: "Error",
            description: "Could not delete grade. Reverting changes.",
        });
        setGrades(originalGrades);
    }
  }

  const selectedStudentName = students.find(s => s.id === selectedStudentId)?.name;

  return (
    <Card>
      <CardHeader className="flex flex-col items-start gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex-1">
          <CardTitle className="font-headline">
            {selectedStudentName ? `Grades for ${selectedStudentName}` : 'Select a student'}
          </CardTitle>
        </div>
        <div className="flex w-full items-center gap-2 md:w-auto">
          <Select
            value={selectedStudentId ?? ""}
            onValueChange={(val) => setSelectedStudentId(val)}
          >
            <SelectTrigger className="flex-1 md:w-[240px]">
              <SelectValue placeholder="Select a student" />
            </SelectTrigger>
            <SelectContent>
              {students.map((student) => (
                <SelectItem key={student.id} value={student.id}>
                  {student.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" disabled={!selectedStudentId}>
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Grade
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Grade for {selectedStudentName}</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleAddGrade)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="assignment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Assignment Name</FormLabel>
                        <FormControl><Input placeholder="e.g. Midterm Exam" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                     <FormField
                        control={form.control}
                        name="score"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Score</FormLabel>
                            <FormControl><Input type="number" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                       <FormField
                        control={form.control}
                        name="total"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Out of</FormLabel>
                            <FormControl><Input type="number" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                  </div>
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button type="button" variant="secondary">Cancel</Button>
                    </DialogClose>
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Save Grade
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex h-64 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
             {!selectedStudentId && (
                <TableCaption>Please select a student to view their grades.</TableCaption>
             )}
             {selectedStudentId && grades.length === 0 && (
                <TableCaption>No grades recorded for this student yet.</TableCaption>
             )}
            <TableHeader>
              <TableRow>
                <TableHead>Assignment</TableHead>
                <TableHead className="w-1/4">Score</TableHead>
                <TableHead className="w-1/4">Percentage</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {grades.map((grade) => (
                <TableRow key={grade.id}>
                  <TableCell className="font-medium">{grade.assignment}</TableCell>
                  <TableCell>{`${grade.score} / ${grade.total}`}</TableCell>
                  <TableCell>{((grade.score / grade.total) * 100).toFixed(1)}%</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteGrade(grade.id)}>
                        <Trash2 className="h-4 w-4 text-destructive"/>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
