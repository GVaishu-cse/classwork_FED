// Import the functions you need from the SDKs you need
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBst8OLMSf_u5tFSVwS-Jy2z31K74_6fzk",
  authDomain: "studio-8114167074-e11b5.firebaseapp.com",
  projectId: "studio-8114167074-e11b5",
  storageBucket: "studio-8114167074-e11b5.appspot.com",
  messagingSenderId: "496003830977",
  appId: "1:496003830977:web:775632201846871b5ab040",
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export { app, auth, db, storage };
