import type { Student } from "@/types";

export const sampleStudents: Student[] = [
  { id: "1", name: "Alice Johnson" },
  { id: "2", name: "Ben Carter" },
  { id: "3", name: "Catherine Davis" },
  { id: "4", name: "David Evans" },
  { id: "5", name: "Emily Foster" },
  { id: "6", name: "Frank Green" },
  { id: "7", name: "Grace Hill" },
  { id: "8", name: "Henry Irving" },
];
