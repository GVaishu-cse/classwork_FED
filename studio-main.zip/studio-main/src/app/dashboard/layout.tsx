"use client";

import { useAuth } from "@/hooks/use-auth";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";

import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarTrigger,
  SidebarInset,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard,
  Presentation,
  UserCheck,
  GraduationCap,
  LogOut,
  Loader2,
  Menu,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/icons/logo";
import { usePathname } from "next/navigation";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [isSigningOut, setIsSigningOut] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
    }
  }, [user, loading, router]);

  const handleSignOut = async () => {
    setIsSigningOut(true);
    try {
      await signOut(auth);
      router.push("/login");
    } catch (error) {
      console.error("Sign out error:", error);
      setIsSigningOut(false);
    }
  };

  if (loading || !user) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/dashboard/whiteboard", label: "Whiteboard", icon: Presentation },
    { href: "/dashboard/attendance", label: "Attendance", icon: UserCheck },
    { href: "/dashboard/grading", label: "Grading", icon: GraduationCap },
  ];
  
  const SidebarNav = () => (
    <SidebarMenu>
      {navItems.map((item) => (
        <SidebarMenuItem key={item.href}>
          <Link href={item.href} passHref>
            <SidebarMenuButton
              isActive={pathname === item.href}
              tooltip={item.label}
            >
              <item.icon />
              <span>{item.label}</span>
            </SidebarMenuButton>
          </Link>
        </SidebarMenuItem>
      ))}
    </SidebarMenu>
  );

  return (
    <SidebarProvider>
      <div className="flex min-h-screen bg-background">
        <Sidebar collapsible="icon" className="hidden md:flex">
          <SidebarHeader>
            <div className="flex items-center gap-2 p-2">
              <Logo className="size-6 text-primary" />
              <span className="font-headline text-lg font-bold group-data-[collapsible=icon]:hidden">
                TeachHub
              </span>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarNav />
          </SidebarContent>
          <SidebarFooter>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton onClick={handleSignOut} disabled={isSigningOut} tooltip="Log Out">
                  {isSigningOut ? <Loader2 className="animate-spin" /> : <LogOut />}
                  <span>Log Out</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1">
          <header className="flex h-14 items-center justify-between border-b bg-background px-4 md:hidden">
            <Link href="/dashboard" className="flex items-center gap-2">
              <Logo className="size-6 text-primary" />
              <span className="font-headline text-lg font-bold">TeachHub</span>
            </Link>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[240px] p-0">
                <div className="flex h-full flex-col">
                  <SidebarHeader className="border-b">
                    <div className="flex items-center gap-2 p-2">
                      <Logo className="size-6 text-primary" />
                      <span className="font-headline text-lg font-bold">
                        TeachHub
                      </span>
                    </div>
                  </SidebarHeader>
                  <SidebarContent className="p-2">
                    <SidebarNav />
                  </SidebarContent>
                  <SidebarFooter className="border-t p-2">
                    <SidebarMenu>
                       <SidebarMenuItem>
                         <SidebarMenuButton onClick={handleSignOut} disabled={isSigningOut}>
                           {isSigningOut ? <Loader2 className="animate-spin" /> : <LogOut />}
                           <span>Log Out</span>
                         </SidebarMenuButton>
                       </SidebarMenuItem>
                    </SidebarMenu>
                  </SidebarFooter>
                </div>
              </SheetContent>
            </Sheet>
          </header>
          <div className="p-4 sm:p-6 lg:p-8">{children}</div>
        </main>
      </div>
    </SidebarProvider>
  );
}
