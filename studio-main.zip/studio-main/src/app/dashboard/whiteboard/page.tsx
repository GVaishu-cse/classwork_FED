import WhiteboardCanvas from "@/components/whiteboard/whiteboard-canvas";

export default function WhiteboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-headline text-3xl font-bold tracking-tight">
          Interactive Whiteboard
        </h1>
        <p className="text-muted-foreground">
          Your digital canvas for teaching. Draw, erase, and save your work.
        </p>
      </div>
      <div className="aspect-[16/9] w-full rounded-lg border bg-white shadow-md">
        <WhiteboardCanvas />
      </div>
    </div>
  );
}
