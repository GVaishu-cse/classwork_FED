import AttendanceManager from "@/components/attendance/attendance-manager";

export default function AttendancePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-headline text-3xl font-bold tracking-tight">
          Attendance Tracker
        </h1>
        <p className="text-muted-foreground">
          Select a date to view and manage student attendance.
        </p>
      </div>
      <AttendanceManager />
    </div>
  );
}
