import GradingManager from "@/components/grading/grading-manager";

export default function GradingPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-headline text-3xl font-bold tracking-tight">
          Grading System
        </h1>
        <p className="text-muted-foreground">
          Select a student to view, add, or edit their grades.
        </p>
      </div>
      <GradingManager />
    </div>
  );
}
