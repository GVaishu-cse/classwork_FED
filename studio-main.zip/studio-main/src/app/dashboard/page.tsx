import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Presentation, UserCheck, GraduationCap } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import placeholderData from "@/lib/placeholder-images.json";

export default function DashboardPage() {
  const { placeholderImages } = placeholderData;

  const features = [
    {
      title: "Interactive Whiteboard",
      description: "Draw, write, and explain concepts on a digital canvas.",
      href: "/dashboard/whiteboard",
      icon: <Presentation className="h-8 w-8 text-primary" />,
      image: placeholderImages.find((img) => img.id === "whiteboard"),
    },
    {
      title: "Attendance Tracker",
      description: "Easily mark and manage student attendance for every class.",
      href: "/dashboard/attendance",
      icon: <UserCheck className="h-8 w-8 text-primary" />,
      image: placeholderImages.find((img) => img.id === "attendance"),
    },
    {
      title: "Grading System",
      description: "Enter, view, and organize student grades and assignments.",
      href: "/dashboard/grading",
      icon: <GraduationCap className="h-8 w-8 text-primary" />,
      image: placeholderImages.find((img) => img.id === "grading"),
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-headline text-3xl font-bold tracking-tight">
          Welcome, Teacher!
        </h1>
        <p className="text-muted-foreground">
          Here are your tools to make teaching a breeze.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {features.map((feature) => (
          <Link href={feature.href} key={feature.title}>
            <Card className="group h-full overflow-hidden transition-all hover:shadow-lg hover:-translate-y-1">
              {feature.image && (
                <div className="overflow-hidden">
                  <Image
                    src={feature.image.imageUrl}
                    alt={feature.image.description}
                    width={600}
                    height={400}
                    data-ai-hint={feature.image.imageHint}
                    className="w-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
              )}
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="font-headline text-xl">
                      {feature.title}
                    </CardTitle>
                    <CardDescription className="mt-1">
                      {feature.description}
                    </CardDescription>
                  </div>
                  {feature.icon}
                </div>
              </CardHeader>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
