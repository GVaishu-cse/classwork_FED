export type Student = {
  id: string;
  name: string;
};

export type Grade = {
  id: string;
  assignment: string;
  score: number;
  total: number;
};

export type AttendanceStatus = "present" | "absent" | "late";

export type AttendanceRecord = {
  [studentId: string]: AttendanceStatus;
};
