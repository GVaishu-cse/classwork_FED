# **App Name**: TeachHub

## Core Features:

- Firebase Authentication: Secure teacher login/signup using Firebase Authentication with email/password.
- Teacher Dashboard: Centralized dashboard providing access to the whiteboard, attendance, and grading tools.
- Whiteboard: Interactive canvas allowing teachers to draw, erase, and save the board as an image to Firestore Storage.
- Attendance Management: Tool to record student attendance by date, class, and student names, stored in Firestore.
- Grading System: Interface for adding, editing, and storing student grades in Firestore.

## Style Guidelines:

- Primary color: Soft Lavender (#E6E6FA) to evoke calmness and serenity.
- Background color: Off-White (#F8F8FF), providing a gentle and distraction-free interface.
- Accent color: Light Sea Green (#20B2AA) to highlight important actions and information with a touch of freshness.
- Headline font: 'Nunito' sans-serif, for a friendly and approachable feel, especially in the dashboard and module headings.
- Body font: 'Open Sans' sans-serif for body text. Ensures excellent readability and a clean interface, complementing the Nunito headings.
- Consistent and clear icons representing each tool (whiteboard, attendance, grading). Icons should have a minimalist style.
- Clean, intuitive layout with clear navigation. Use CSS Grid and Flexbox for responsiveness.
- Subtle transitions and animations for loading states and interactive elements to enhance user experience, maintaining a peaceful atmosphere.